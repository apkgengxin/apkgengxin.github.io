window.hm_url = "";
window.line_1 = "https://www.baidu.com/";
window.line_2 = "https://www.baidu.com/";
window.line_3 = "https://www.baidu.com/";
window.default_line = "https://www.baidu.com/";